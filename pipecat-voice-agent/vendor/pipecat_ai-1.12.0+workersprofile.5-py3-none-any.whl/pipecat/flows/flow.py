#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""A flow config joined to the application's handlers.

A :class:`Flow` is a :class:`~pipecat.flows.FlowConfig` joined to the code it
names: the config's nodes turned into runnable
:data:`~pipecat.flows.NodeConfig` dicts, with every tool reference resolved
to a Flows direct function, every ``transition_only`` function built from the
config alone, and every transition wired to the node the config names.

Constructing a flow validates the references the config could not: each
tool exists and has a valid direct-function signature, each ``function``
action names a callable. Tool return values are checked at call time against
the configured-flow contract: a tool returns ``(result, TRANSITION_IN_YAML)``
and the config decides the next node. ``{{ key }}`` placeholders in prompts
are left in place; :class:`~pipecat.flows.FlowManager` fills them from its
state when it enters the node.
"""

import inspect
import re
from collections.abc import Callable, Mapping, Sequence
from typing import TYPE_CHECKING, Any

from loguru import logger

from pipecat.flows.config import case_key
from pipecat.flows.exceptions import FlowError, FlowProblem, FlowReferenceError
from pipecat.flows.types import (
    NO_RESPONSE,
    TRANSITION_IN_YAML,
    ActionConfig,
    ConsolidatedFunctionResult,
    ContextStrategyConfig,
    FlowArgs,
    FlowsDirectFunction,
    FlowsDirectFunctionWrapper,
    FlowsFunctionSchema,
    NodeConfig,
)

if TYPE_CHECKING:
    from pipecat.flows.config import FlowConfig
    from pipecat.flows.manager import FlowManager


class Flow:
    """A :class:`~pipecat.flows.FlowConfig` joined to handlers.

    The flow hands ready-made node configs to
    :class:`~pipecat.flows.FlowManager`::

        config = FlowConfig.from_file("flow.yaml")
        flow = Flow(config, handlers=handlers)
        flow_manager = FlowManager(..., global_functions=flow.global_functions)
        await flow_manager.initialize(flow.initial_node)
    """

    def __init__(
        self,
        config: "FlowConfig",
        *,
        handlers: Mapping[str, Callable] | Sequence[Mapping[str, Callable] | Any] | Any,
    ):
        """Join a config to the handlers it refers to.

        Args:
            config: The flow config.
            handlers: The Python behind the config: the direct functions
                that implement its tools and the callables that implement
                its actions. A mapping of names to callables, or any object
                whose attributes are the callables, typically a module. A
                list or tuple of those lets tools and action handlers live in
                separate modules; a name that resolves to different callables
                in more than one of them is an error rather than a silent
                choice. Only the names the config references are looked up.

        Raises:
            ~pipecat.flows.FlowReferenceError: If a referenced tool or handler
                is missing or ambiguous, or a tool is not a valid direct
                function. Every such problem is collected and reported
                together.
        """
        self._config = config
        self._handlers = list(handlers) if isinstance(handlers, (list, tuple)) else [handlers]
        self._problems: list[FlowProblem] = []

        self._nodes: dict[str, NodeConfig] = {
            name: self._build_node(name, node) for name, node in config.nodes.items()
        }
        self._global_functions = [
            schema
            for ref in config.global_functions
            if (schema := self._build_function(ref, where="global_functions", node=None))
        ]
        # Building continues past each problem so all of them are found; the
        # partially built state never escapes because this raise comes last.
        if self._problems:
            raise FlowReferenceError(self._problems)

    @property
    def config(self) -> "FlowConfig":
        """The config this flow was constructed from."""
        return self._config

    @property
    def initial_node(self) -> NodeConfig:
        """The node config the flow starts in."""
        return self._nodes[self._config.initial_node]

    @property
    def global_functions(self) -> list[FlowsFunctionSchema | FlowsDirectFunction]:
        """Tools available at every node, for ``FlowManager(global_functions=...)``.

        A fresh list each time, so the caller may extend it.
        """
        return list(self._global_functions)

    def node(self, name: str) -> NodeConfig:
        """The node config for ``name``.

        Args:
            name: A node name from the config.

        Raises:
            ~pipecat.flows.FlowError: If the config has no such node.
        """
        try:
            return self._nodes[name]
        except KeyError:
            raise FlowError(f"flow has no node '{name}'") from None

    # Building

    def _build_node(self, name: str, node: "FlowConfig.Node") -> NodeConfig:
        where = f"node '{name}'"
        config: NodeConfig = {
            "name": name,
            "task_messages": [{"role": m.role, "content": m.content} for m in node.task_messages],
            "respond_immediately": node.respond_immediately,
        }
        if node.role_message is not None:
            config["role_message"] = node.role_message
        if node.functions:
            config["functions"] = [
                schema
                for ref in node.functions
                if (schema := self._build_function(ref, where=where, node=name))
            ]
        if node.pre_actions:
            config["pre_actions"] = [
                self._build_action(a, where=f"{where} pre_actions", node=name)
                for a in node.pre_actions
            ]
        if node.post_actions:
            config["post_actions"] = [
                self._build_action(a, where=f"{where} post_actions", node=name)
                for a in node.post_actions
            ]
        strategy = node.context_strategy_enum()
        if strategy is not None:
            config["context_strategy"] = ContextStrategyConfig(strategy=strategy)
        return config

    def _build_function(
        self, ref: "FlowConfig.Function", *, where: str, node: str | None
    ) -> FlowsFunctionSchema | None:
        """Build the schema for one function entry, or record why it cannot be built."""
        if ref.transition_only:
            return FlowsFunctionSchema(
                name=ref.name,
                description=ref.description or "",
                properties={},
                required=[],
                handler=self._make_transition_handler(ref),
            )
        function = self._lookup(ref.name, kind="tool", where=where, node=node)
        if function is None:
            return None
        try:
            wrapper = FlowsDirectFunctionWrapper(function)
        except Exception as e:
            self._problem(
                "invalid_tool",
                f"{where} tool '{ref.name}' is not a valid direct function: {e}",
                node=node,
                function=ref.name,
            )
            return None
        _warn_if_annotated_with_node(function, ref.name, where)

        # The config's name is the tool's identity: it is what the LLM sees,
        # what the config's other entries and the evals refer to, and it may
        # map several names to one callable.
        schema = wrapper.to_function_schema()
        return FlowsFunctionSchema(
            name=ref.name,
            description=schema.description,
            properties=schema.properties,
            required=schema.required,
            handler=self._make_handler(ref, wrapper, where),
            cancel_on_interruption=wrapper.cancel_on_interruption,
            timeout_secs=wrapper.timeout_secs,
        )

    def _build_action(self, action: "FlowConfig.Action", *, where: str, node: str) -> ActionConfig:
        config: ActionConfig = {"type": action.type}
        if action.handler is not None:
            handler = self._lookup(action.handler, kind="action handler", where=where, node=node)
            if handler is not None:
                config["handler"] = handler
        for key, value in action.extras().items():
            config[key] = value  # type: ignore[literal-required]
        return config

    def _lookup(self, name: str, *, kind: str, where: str, node: str | None) -> Callable | None:
        """Resolve ``name`` in the handlers, or record why it cannot be resolved."""
        is_tool = kind == "tool"
        matches: dict[int, tuple[Any, Callable]] = {}
        for index, namespace in enumerate(self._handlers):
            if isinstance(namespace, Mapping):
                target = namespace.get(name)
            else:
                target = getattr(namespace, name, None)
            # The same callable reachable through two namespaces is one tool,
            # not a conflict.
            if target is not None and id(target) not in matches:
                matches[id(target)] = (index, target)
        if len(matches) > 1:
            found = ", ".join(self._describe_namespace(i) for i, _ in matches.values())
            self._problem(
                "ambiguous_tool" if is_tool else "ambiguous_handler",
                f"{where} {kind} '{name}' is defined in more than one of the handlers ({found})",
                node=node,
                function=name if is_tool else None,
            )
            return None
        target = next(iter(matches.values()))[1] if matches else None
        if target is None:
            self._problem(
                "missing_tool" if is_tool else "missing_handler",
                f"{where} references {kind} '{name}', which is not in the handlers",
                node=node,
                function=name if is_tool else None,
            )
            return None
        if not callable(target):
            self._problem(
                "invalid_tool" if is_tool else "missing_handler",
                f"{where} {kind} '{name}' is not callable",
                node=node,
                function=name if is_tool else None,
            )
            return None
        return target

    def _describe_namespace(self, index: int) -> str:
        namespace = self._handlers[index]
        name = getattr(namespace, "__name__", None)
        return f"handlers[{index}] {name}" if isinstance(name, str) else f"handlers[{index}]"

    def _problem(
        self, code: str, message: str, *, node: str | None = None, function: str | None = None
    ) -> None:
        self._problems.append(FlowProblem(code, message, node=node, function=function))

    # Calling

    def _make_handler(
        self, ref: "FlowConfig.Function", wrapper: FlowsDirectFunctionWrapper, where: str
    ) -> Callable[[FlowArgs, "FlowManager"], Any]:
        async def handler(
            args: FlowArgs, flow_manager: "FlowManager"
        ) -> ConsolidatedFunctionResult:
            response = await wrapper.invoke(args, flow_manager)
            result, next_node = _check_contract(response, ref.name, where)
            if next_node is NO_RESPONSE:
                return result, NO_RESPONSE
            return result, self._destination(ref, result, where)

        return handler

    def _make_transition_handler(
        self, ref: "FlowConfig.Function"
    ) -> Callable[[FlowArgs, "FlowManager"], Any]:
        async def handler(
            args: FlowArgs, flow_manager: "FlowManager"
        ) -> ConsolidatedFunctionResult:
            return None, self._nodes[ref.transition_to]  # type: ignore[index]

        return handler

    def _destination(
        self, ref: "FlowConfig.Function", result: Any, where: str
    ) -> NodeConfig | None:
        target = ref.transition_to
        if target is None:
            return None
        if isinstance(target, str):
            return self._nodes[target]

        if not isinstance(result, Mapping) or target.field not in result:
            raise FlowError(
                f"{where} tool '{ref.name}' branches on result field '{target.field}', "
                f"but its result has no such field"
            )
        node_name = target.cases.get(case_key(result[target.field]), target.default)
        if node_name is None:
            logger.debug(f"{where} tool '{ref.name}': no branch case matched, staying")
            return None
        return self._nodes[node_name]


def _check_contract(response: Any, name: str, where: str) -> tuple[Any, Any]:
    """Check a tool's return value against the configured-flow contract.

    A tool returns ``(result, TRANSITION_IN_YAML)``, or ``(result, NO_RESPONSE)``
    to stay on the node without a bot turn.
    """
    if not isinstance(response, tuple) or len(response) != 2:
        raise FlowError(
            f"{where} tool '{name}' must return a (result, next) tuple; "
            f"got {type(response).__name__}"
        )
    result, next_node = response
    if next_node is NO_RESPONSE or next_node is TRANSITION_IN_YAML:
        return result, next_node
    if isinstance(next_node, str):
        raise FlowError(
            f"{where} tool '{name}' returned node name '{next_node}', but the flow config "
            f"decides its transition; return (result, {TRANSITION_IN_YAML!r})"
        )
    if next_node is None:
        raise FlowError(
            f"{where} tool '{name}' returned None as the next node; in a configured flow "
            f"return (result, {TRANSITION_IN_YAML!r}) to let the config decide"
        )
    raise FlowError(
        f"{where} tool '{name}' returned a next node; in a configured flow the config "
        f"owns transitions, so return (result, {TRANSITION_IN_YAML!r})"
    )


def _warn_if_annotated_with_node(function: Callable, name: str, where: str) -> None:
    """Log when a tool's return annotation mentions ``NodeConfig``.

    A configured-flow tool returns the ``TRANSITION_IN_YAML`` sentinel in the
    next-node slot, so an annotation that names ``NodeConfig`` there, including
    ``NodeConfig | None`` and the ``ConsolidatedFunctionResult`` alias, says the
    tool was written for a flow built in Python.
    """
    try:
        annotation = inspect.signature(function).return_annotation
    except (TypeError, ValueError):
        return
    if annotation is inspect.Signature.empty:
        return
    text = annotation if isinstance(annotation, str) else repr(annotation)
    if "NodeConfig" in text:
        logger.warning(
            f"{where} tool '{name}' is annotated as returning a NodeConfig; "
            f"in a configured flow it must return (result, {TRANSITION_IN_YAML!r})"
        )
